package org.zad;
import android.app.Activity;import android.os.Bundle;import android.content.*;import android.widget.Toast;
public class CopyActivity extends Activity {
 boolean copied=false;
 @Override public void onCreate(Bundle b){super.onCreate(b);}
 @Override public void onWindowFocusChanged(boolean focus){super.onWindowFocusChanged(focus);if(focus&&!copied){copied=true;String text=getIntent().getStringExtra("text");if(text==null)text=Data.header(this)+"\n\n"+Data.body(this);((ClipboardManager)getSystemService(CLIPBOARD_SERVICE)).setPrimaryClip(ClipData.newPlainText("زاد الصالحين",text));Toast.makeText(this,"تم نسخ الحديث",Toast.LENGTH_SHORT).show();finish();}}
}
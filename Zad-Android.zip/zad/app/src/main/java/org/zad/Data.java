package org.zad;
import android.content.*;import org.json.*;import java.io.*;
class Data {
 static JSONArray rows; static JSONObject root;
 static void load(Context c){if(rows!=null)return;try(InputStream in=c.getAssets().open("hadith.json")){ByteArrayOutputStream b=new ByteArrayOutputStream();byte[] buf=new byte[8192];int n;while((n=in.read(buf))!=-1)b.write(buf,0,n);root=new JSONObject(b.toString("UTF-8"));rows=root.getJSONArray("hadiths");}catch(Exception e){rows=new JSONArray();}}
 static android.content.SharedPreferences prefs(Context c){return c.getSharedPreferences("zad",0);}
 static int index(Context c){load(c);return Math.floorMod(prefs(c).getInt("index",0),Math.max(1,rows.length()));}
 static JSONObject item(Context c){load(c);JSONObject j=rows.optJSONObject(index(c));return j==null?new JSONObject():j;}
 static String body(Context c){return item(c).optString("arabic","تعذر تحميل الأحاديث");}
 static String header(Context c){JSONObject j=item(c);int chapter=j.optInt("chapterId");String name="";if(root!=null){JSONArray a=root.optJSONArray("chapters");if(a!=null)for(int i=0;i<a.length();i++){JSONObject x=a.optJSONObject(i);if(x!=null&&x.optInt("id")==chapter){name=x.optString("arabic");break;}}}return name+" • الحديث "+j.optInt("idInBook",index(c)+1);}
 static void move(Context c,int d){prefs(c).edit().putInt("index",index(c)+d).apply();}
}
